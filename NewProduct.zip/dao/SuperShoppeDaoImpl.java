package com.cg.NewProduct.dao;

import java.util.Map;

import com.cg.NewProduct.Exception.ISuperShoppeException;
import com.cg.NewProduct.bean.Product;
import com.cg.NewProduct.bean.Supplier;
import com.cg.NewProduct.utility.SuperShoppeDB;

public class SuperShoppeDaoImpl implements ISuperShoppeDAO {

	
	
	
	@Override
	public int addProduct(Product product) throws ISuperShoppeException {
		// TODO Auto-generated method stub
		Map<Integer, Product> map = SuperShoppeDB.getProducts();
		double randomNumber = Math.random() * 1000;

		int generatedId = (int) randomNumber;

		map.put(generatedId, product);

		return generatedId;
	}

	@Override	
	public Map<Integer, Product> getAllproducts() throws ISuperShoppeException {
		// TODO Auto-generated method stub
		return SuperShoppeDB.getProducts();
	}

	@Override
	public int addSupplier(Supplier supplier) throws ISuperShoppeException {
		// TODO Auto-generated method stub
		Map<Integer, Supplier> map1 = SuperShoppeDB.getSuppliers();
		double randomNumber = Math.random() * 1000;

		int generatedId = (int) randomNumber;

		map1.put(generatedId, supplier);

		return generatedId;
	}

	@Override
	public Map<Integer, Supplier> getAllsuppliers() throws ISuperShoppeException {
		// TODO Auto-generated method stub
		return SuperShoppeDB.getSuppliers();
	}

}
