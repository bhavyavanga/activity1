package com.cg.NewProduct.dao;

import java.util.Map;

import com.cg.NewProduct.Exception.ISuperShoppeException;
import com.cg.NewProduct.bean.Product;
import com.cg.NewProduct.bean.Supplier;

public interface ISuperShoppeDAO {

	public int addProduct(Product product) throws ISuperShoppeException;

	public Map<Integer, Product> getAllproducts() throws ISuperShoppeException;
	
	public int addSupplier(Supplier supplier) throws ISuperShoppeException;

	public Map<Integer, Supplier> getAllsuppliers() throws ISuperShoppeException;
	
}
