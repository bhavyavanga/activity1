package com.cg.NewProduct.Service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.NewProduct.Exception.ISuperShoppeException;
import com.cg.NewProduct.bean.Product;
import com.cg.NewProduct.bean.Supplier;
import com.cg.NewProduct.dao.ISuperShoppeDAO;
import com.cg.NewProduct.dao.SuperShoppeDaoImpl;

public class ShopperShoppeServiceImpl implements ISuperShoppeService {

	ISuperShoppeDAO superShoppeDao = new SuperShoppeDaoImpl();
	
	@Override
	public boolean validateName(String Name) throws ISuperShoppeException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, Name)) {
			throw new ISuperShoppeException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	@Override
	public boolean validateNumber(String mobileNo) throws ISuperShoppeException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public int addProduct(Product product) throws ISuperShoppeException {
		// TODO Auto-generated method stub
		return superShoppeDao.addProduct(product);
	}
	@Override
	public Map<Integer, Product> getAllproducts() throws ISuperShoppeException {
		// TODO Auto-generated method stub
		return superShoppeDao.getAllproducts();
	}
	@Override
	public int addSupplier(Supplier supplier) throws ISuperShoppeException {
		// TODO Auto-generated method stub
		return superShoppeDao.addSupplier(supplier);
	}
	@Override
	public Map<Integer, Supplier> getAllsuppliers() throws ISuperShoppeException {
		// TODO Auto-generated method stub
		return superShoppeDao.getAllsuppliers();
	}

}
