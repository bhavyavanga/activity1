package com.cg.NewProduct.Service;

import java.util.Map;

import com.cg.NewProduct.Exception.ISuperShoppeException;
import com.cg.NewProduct.bean.Product;
import com.cg.NewProduct.bean.Supplier;

public interface ISuperShoppeService {
	public boolean validateName(String Name) throws ISuperShoppeException;

	public boolean validateNumber(String mobileNo) throws ISuperShoppeException;
	
	public int addProduct(Product product) throws ISuperShoppeException;

	public Map<Integer, Product> getAllproducts() throws ISuperShoppeException;
	
	public int addSupplier(Supplier supplier) throws ISuperShoppeException;

	public Map<Integer, Supplier> getAllsuppliers() throws ISuperShoppeException;

	
}
