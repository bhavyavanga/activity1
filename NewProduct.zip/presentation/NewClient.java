package com.cg.NewProduct.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.NewProduct.Exception.ISuperShoppeException;
import com.cg.NewProduct.Service.ShopperShoppeServiceImpl;
import com.cg.NewProduct.bean.Product;
import com.cg.NewProduct.bean.Supplier;

public class NewClient {

	static ShopperShoppeServiceImpl service = new ShopperShoppeServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	static void addProductDetails() {
		boolean productNameFlag = false;
		System.out.println("Enter productId");
		int productId = scanner.nextInt();
		System.out.println("Enter productName");
		String productName = scanner.next();
		System.out.println("Enter Price");
		double price = scanner.nextInt();
		System.out.println("Enter quantity");
		int quantity = scanner.nextInt();

		try {
			service.validateName(productName);
			productNameFlag = true;
		} catch (ISuperShoppeException e) {
			productNameFlag = false;
			System.err.println(e.getMessage());
		}
		

		try {
			Product product = new Product(productId,productName, price, quantity);
			int genearatedId = service.addProduct(product);
			System.out.println("product stored with the given id: " + genearatedId);
		} catch (ISuperShoppeException e) {
			System.err.println(e.getMessage());
		}
	}

	static void addSupplierDetails() {
		boolean supplierNameFlag = false;
		boolean mobileNoFlag = false;
		System.out.println("Enter supplierId");
		int supplierId = scanner.nextInt();
		System.out.println("Enter supplierName");
		String supplierName = scanner.next();
		scanner.nextLine();
		System.out.println("Enter mobileNo");
		String mobileNo = scanner.next();
		scanner.nextLine();
		System.out.println("Enter address");
		String address = scanner.next();
		scanner.nextLine();
		try {
			service.validateName(supplierName);
			supplierNameFlag = true;
		} catch (ISuperShoppeException e) {
			supplierNameFlag = false;
			System.err.println(e.getMessage());
		}
		try {
			
			service.validateNumber(mobileNo);
			mobileNoFlag = true;
		} catch (InputMismatchException e) {
			mobileNoFlag = false;
			System.err.println("number should be in digits");
		} catch (ISuperShoppeException e) {
			mobileNoFlag = false;
			System.err.println(e.getMessage());
		}
		
		try {
			Supplier supplier = new Supplier(supplierId,supplierName, mobileNo, address);
			int genearatedId = service.addSupplier(supplier);
			System.out.println("product stored with the given id: " + genearatedId);
		} catch (ISuperShoppeException e) {
			System.err.println(e.getMessage());
		}
	}

	public static void main(String args[]) {

		String option = null;
		do {
			System.out.println("1.addProductDetails\n 2.addSupplierDetails\n 3.ViewAll");
			int choice = scanner.nextInt();
			switch (choice) {
			case 0:
				System.exit(0);
			case 1:
				addProductDetails();
				break;
			case 2:
				addSupplierDetails();
				break;
			case 3: {
				try {
					Map<Integer, Product> products = service.getAllproducts();

					Iterator<Integer> iterator = products.keySet().iterator();
					while (iterator.hasNext()) {
						int id = iterator.next();
						Product productData = products.get(id);
						System.out.println(id + ": " + productData);
					}

				} catch (ISuperShoppeException e) {
					System.err.println(e.getMessage());
				}
				try {
					Map<Integer, Supplier> suppliers = service.getAllsuppliers();

					Iterator<Integer> iterator = suppliers.keySet().iterator();
					while (iterator.hasNext()) {
						int id = iterator.next();
						Supplier supplierData = suppliers.get(id);
						System.out.println(id + ": " + supplierData);
					}

				} catch (ISuperShoppeException e) {
					System.err.println(e.getMessage());
				}
				break;
			}

			}
			System.out.println("press y to continue");
			option = scanner.next();
		} while (option.equalsIgnoreCase("y"));
	}
}
