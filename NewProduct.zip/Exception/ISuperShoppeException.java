package com.cg.NewProduct.Exception;

public class ISuperShoppeException extends Exception {

	public ISuperShoppeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
