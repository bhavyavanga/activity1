
package com.cg.NewProduct.utility;

import java.util.Map;
import java.util.TreeMap;

import com.cg.NewProduct.bean.Product;
import com.cg.NewProduct.bean.Supplier;

public class SuperShoppeDB {

	private static Map<Integer, Product> products = new TreeMap<>();
	private static Map<Integer, Supplier> suppliers = new TreeMap<>();
	static {

		products.put(111, new Product(111,"Activa", 65000, 2));
		products.put(222, new Product(222,"Access", 55000, 2));
		products.put(333, new Product(333,"Unicorn", 95000, 1));
		
		suppliers.put(11, new Supplier(11,"bhavya", "9876543210", "banglore"));
		suppliers.put(22, new Supplier(22,"dvhbnhk", "9876255000", "chennai"));
		suppliers.put(33, new Supplier(33,"Unicorn", "9500046312", "pune"));
		
		
	}

	public static Map<Integer, Product> getProducts() {
		return products;
	}

	public static void setProducts(Map<Integer, Product> products) {
		SuperShoppeDB.products = products;
	}

	public static Map<Integer, Supplier> getSuppliers() {
		return suppliers;
	}

	public static void setSuppliers(Map<Integer, Supplier> suppliers) {
		SuperShoppeDB.suppliers = suppliers;
	}
	
	
}
